import pandas as pd
from typing import Literal, List

class Preprocessor:
    def __init__(self):
        pass
    
    def removeNullValues(self) -> pd.DataFrame:  
        pass
    
    def removeDuplicates(self) -> pd.DataFrame:
        pass
    
    def mergeDataframes(self, dataframes:List[pd.DataFrame], merge_type:Literal['left','inner','outer','right']) -> pd.DataFrame:
        pass
    
    def removeColumns(self, dataframe, columns = []) -> pd.DataFrame:
        pass
    
    def removeHolidays(self, dataframe)-> pd.DataFrame:
        pass
    
    def removeRecordsBeforeJoiningDate(self, dataframe)-> pd.DataFrame:
        pass
    
    def removeRecordsAfterLeavingDate(self, dataframe)-> pd.DataFrame:
        pass 
    
    def renameColumns(self, dataframe, rename_columns = {})-> pd.DataFrame:
        pass
    
    