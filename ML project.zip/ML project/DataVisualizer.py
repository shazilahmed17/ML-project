class Visualizer:
    def __init__(self):
        pass
    
    def scatterPlot(self, dataframe, columns_x_axis = [], columns_y_axis = []):
        pass
    
    def LinePlot(self, dataframe, columns_x_axis = [], columns_y_axis = []):
        pass
    
    def scatterPlot(self, dataframe, columns_x_axis = [], columns_y_axis = []):
        pass