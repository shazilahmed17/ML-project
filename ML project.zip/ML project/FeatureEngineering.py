class FeatureEngineer:
    def __init__(self,):
        pass
    
    def findCorrelation(self):
        pass
    
    def labelEncoding(self):
        pass
    
    def oneHotEncoding(self):
        pass
    
    def dropFeatures(self, features=[]):
        pass