class ModelTrainer:
    def __init__(self):
        pass
    
    def trainRandomForest(self, data, no_trees, depth, random_state):
        pass
    
    def trainSVM(self, data, kernel):
        pass
    
    def trainLogisticRegression(self):
        pass
    
    